const cloudinary = require('../config/cloudinary')
const todoModel = require('../models/todoModel')

exports.createTodo = async (req, res) => {

  console.log(req.body)

  try{
 let imageData = {}

  if(req.file){
    const upload = await cloudinary.uploader.upload(req.file.path, {
      folder : "todos"
    })

      imageData = {
    url : upload.secure_url,
    p_id : upload.public_id
  }
  }



  const todo = await todoModel.create({
    title : req.body.title,
    desc : req.body.desc,
    image : imageData
  })

  res.status(201).json(todo)
}
 catch(err){
    res.status(500).json({ message: err.message });
  }
  }
 

 


exports.getTodo = async (req, res) => {
  const todos = await todoModel.find().sort({createdAt : -1});
  res.json(todos)
}


exports.updateTodo = async (req, res) => {
  const todo = await todoModel.findById(req.params.id)

  if(!todo){
    return res.status(404).json({
      message : 'todo not found'
    })
  }

  if(req.file){
    if(todo.image?.p_id){
      await cloudinary.uploader.destroy(todo.image.p_id)
    }
  }

  const upload = await cloudinary.uploader.upload(req.file.path, {
    folder : 'todos'
  })

  todo.image = {
    url : upload.secure_url,
    p_id : upload.public_id
  }

  todo.title = req.body.title
  todo.desc = req.body.desc
  await todo.save()

  res.json(todo)
}


exports.deleteTodo = async (req, res) => {
  const todo = await todoModel.findById(req.params.id)
  if(!todo){
    return res.status(404).json({
      message : 'todo not found'
    })
  }

  if(todo.image?.p_id){
    await cloudinary.uploader.destroy(todo.image.p_id)
  }

  await todo.deleteOne()
  res.json({
    message : 'todo deleted'
  })
}